import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CustomerManagerImpl implements CustomerManager {
    private Map<String, Customer> customers = new HashMap<>();
    private static final String CUSTOMER_DIR = "./customers/";
    private static final String INSURANCE_CARD_DIR = "./insurance cards/";

    public CustomerManagerImpl() {
        new File(CUSTOMER_DIR).mkdirs();
        new File(INSURANCE_CARD_DIR).mkdirs();
        loadCustomers();
    }

    @Override
    public boolean addCustomer(Customer customer) throws IOException {
        // 고객 ID 생성 및 설정
        String customerId = "c-" + ThreadLocalRandom.current().nextInt(1000000, 10000000);
        customer.setId(customerId);

        // 고객 정보 저장
        customers.put(customerId, customer);
        saveCustomer(customer); // 고객 정보를 파일에 저장하는 메서드 구현 필요

        // 고객의 인슈어런스 카드 생성 및 저장
        String customerCardId = createAndSaveInsuranceCard(customerId, customerId, true, customer.getFullName());
        customer.addInsuranceCardId(customerCardId); // 여기서 고객의 인슈어런스 카드 ID를 추가

        // 디펜던트의 인슈어런스 카드 생성 및 저장
        for (Dependent dependent : customer.getDependents()) {
            String dependentCardId = createAndSaveInsuranceCard(dependent.getId(), customerId, false, dependent.getFullName());
            dependent.setInsuranceCardId(dependentCardId); // 디펜던트에게 고유한 카드 번호 설정
            dependent.setPolicyOwnerId(customerId); // 여기서 디펜던트의 policyOwnerId를 설정
        }

        saveCustomer(customer); // 변경된 고객 정보를 다시 저장합니다.

        return true; // 성공적으로 추가되었음을 의미
    }

    private String createAndSaveInsuranceCard(String cardHolderId, String policyOwnerId, boolean isPolicyHolder, String cardHolderName) {
        String cardNumber = generateRandomCardNumber();
        Date expirationDate = generateCardExpirationDate();
        InsuranceCard card = new InsuranceCard(cardNumber, cardHolderId, policyOwnerId, expirationDate, cardHolderName);
        saveInsuranceCard(card);
        return cardNumber; // 인슈어런스 카드 번호 반환
    }

    private void saveInsuranceCard(InsuranceCard card, String cardHolderId) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(INSURANCE_CARD_DIR + cardHolderId + "_insurance_card.txt"))) {
            oos.writeObject(card);
        }
    }

    private String generateRandomCardNumber() {
        return Long.toString(ThreadLocalRandom.current().nextLong(1000000000L, 10000000000L));
    }

    private Date generateCardExpirationDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, 1);
        return calendar.getTime();
    }

    private void saveInsuranceCard(InsuranceCard card) {
        String filename = INSURANCE_CARD_DIR + card.getCardHolderId() + "_insurance_card.txt";
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(card);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Customer getCustomerById(String id) {
        return customers.get(id);
    }

    @Override
    public List<Customer> getAllCustomers() {
        return new ArrayList<>(customers.values());
    }

    @Override
    public boolean deleteCustomer(String id) throws IOException {
        Customer customer = customers.remove(id);
        if (customer != null) {
            // 인슈어런스 카드 삭제 로직
            deleteInsuranceCard(customer.getId());
            // 고객 삭제 로직
            try {
                Files.deleteIfExists(Paths.get(CUSTOMER_DIR + id + ".txt"));
                return true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    private void deleteInsuranceCards(Customer customer) throws IOException {
        Files.deleteIfExists(Paths.get(INSURANCE_CARD_DIR + customer.getId() + "_insurance_card.txt"));
        for (Dependent dependent : customer.getDependents()) {
            Files.deleteIfExists(Paths.get(INSURANCE_CARD_DIR + dependent.getId() + "_insurance_card.txt"));
        }
    }

    private void deleteInsuranceCard(String cardHolderId) {
        String filename = INSURANCE_CARD_DIR + cardHolderId + "_insurance_card.txt";
        try {
            Files.deleteIfExists(Paths.get(filename));
            System.out.println("Deleted insurance card for: " + cardHolderId);
        } catch (IOException e) {
            System.out.println("Failed to delete insurance card for: " + cardHolderId);
            e.printStackTrace();
        }
    }

    @Override
    public boolean updateCustomer(Customer customer) throws IOException {
        Customer existingCustomer = customers.get(customer.getId());
        if (existingCustomer == null) {
            System.out.println("Customer not found.");
            return false;
        }

        // 기존 디펜던트의 인슈어런스 카드 삭제
        for (Dependent dependent : existingCustomer.getDependents()) {
            String dependentInsuranceCardFilename = INSURANCE_CARD_DIR + dependent.getInsuranceCardId() + "_insurance_card.txt";
            Files.deleteIfExists(Paths.get(dependentInsuranceCardFilename));
        }

        // 고객 정보 업데이트
        existingCustomer.setFullName(customer.getFullName());
        existingCustomer.setDependents(customer.getDependents());

        // 새 디펜던트의 인슈어런스 카드 생성 및 저장
        for (Dependent newDependent : customer.getDependents()) {
            String dependentCardId = createAndSaveInsuranceCard(newDependent.getId(), customer.getId(), false, newDependent.getFullName());
            newDependent.setInsuranceCardId(dependentCardId);
        }

        saveCustomer(existingCustomer); // 업데이트된 고객 정보 저장
        return true;
    }

    private void deleteInsuranceCardsForCustomer(Customer customer) throws IOException {
        Files.deleteIfExists(Paths.get(INSURANCE_CARD_DIR + customer.getId() + "_insurance_card.txt"));
        for (Dependent dependent : customer.getDependents()) {
            Files.deleteIfExists(Paths.get(INSURANCE_CARD_DIR + dependent.getId() + "_insurance_card.txt"));
        }
    }

    private void generateAndSaveInsuranceCards(Customer customer) throws IOException {
        // Assuming createAndSaveInsuranceCard is already implemented as shown earlier
        createAndSaveInsuranceCard(customer.getId(), customer.getId(), true, customer.getFullName());
        for (Dependent dependent : customer.getDependents()) {
            createAndSaveInsuranceCard(dependent.getId(), customer.getId(), false, dependent.getFullName());
        }
    }



    @Override
    public void saveCustomers() {
        customers.values().forEach(customer -> {
            try {
                saveCustomer(customer);
            } catch (IOException e) {
                System.err.println("Error saving customer " + customer.getId() + ": " + e.getMessage());
                // 여기에 로깅 라이브러리를 사용하는 등의 추가적인 오류 처리를 할 수 있습니다.
            }
        });
    }

    @Override
    public void loadCustomers() {
        File folder = new File(CUSTOMER_DIR);
        File[] files = folder.listFiles((dir, name) -> name.endsWith(".txt"));
        for (File file : files) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                Customer customer = (Customer) ois.readObject();
                customers.put(customer.getId(), customer);
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveCustomer(Customer customer) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(CUSTOMER_DIR + customer.getId() + ".txt"))) {
            oos.writeObject(customer);
        } catch (IOException e) {
            // saveCustomer 메서드에서 발생하는 IOException을 여기에서 catch하고 다시 throw합니다.
            // 이렇게 함으로써, IOException을 호출하는 곳에서 처리할 수 있도록 합니다.
            throw e;
        }
    }
}
